import { ModuleWithProviders } from '@angular/core';
import { RouterModule }        from '@angular/router';
import { RootComponent } from '../dashboard/root/root.component';
import { WorkerComponent } from './worker/worker.component';

export const routingCatalog: ModuleWithProviders = RouterModule.forChild([
  {
      path: 'catalog', component: RootComponent,
      children: [      
       { path: 'worker',  component: WorkerComponent, data: { title: 'Worker'} },
      ]       
    }  
]);

