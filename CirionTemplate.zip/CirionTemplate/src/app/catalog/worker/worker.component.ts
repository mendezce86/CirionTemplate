import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource, MatSortable } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SweetAlert } from 'src/app/shared/services/sweet.alert';
import { Worker } from '../models/worker.class';
import { NotificationService } from 'src/app/shared/services/notification.service';

@Component({
  selector: 'app-worker',
  templateUrl: './worker.component.html',
  styleUrls: ['./worker.component.scss']
})
export class WorkerComponent implements OnInit, OnDestroy {
  private workersList: Array<Worker>;

  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  addUpdateWorkerFrm: FormGroup;
  private workerSelected: Worker;
  action: string;
  private nextId: number;
  
  displayedColumns: string[] = ['firstName', 'lastName', 'birthday', 'gender', 'actions'];
  dataSource = new MatTableDataSource<Worker>();
  
  constructor(private fb: FormBuilder, private sweetAlert: SweetAlert, private notifyService: NotificationService) { 
    this.addUpdateWorkerFrm = this.fb.group({  
      firstName: [null, [Validators.required]], 
      lastName: [null, [Validators.required]], 
      birthday: [null, [Validators.required]],  
      gender: [null, [Validators.required]],  
    });
  }

  ngOnInit() {
    this.workersList = [
            new Worker(1, "Carlos", "Mendez Linares", new Date('1986-01-08'), "Male"),
            new Worker(2, "Jesus", "Cirion Otero", new Date('1984-03-03'), "Male"),
            new Worker(3, "Omayda", "Linares Hernandez", new Date('1984-03-03'), "Female"),
            new Worker(4, "Ronny", "Cirion Otero", new Date('1984-03-03'), "Male"),
            new Worker(5, "John", "Yusk Hernandez", new Date('1988-12-03'), "Male"),
            new Worker(6, "Jaime", "Briyant Milk", new Date('1984-06-07'), "Male"),
            new Worker(7, "Cynthia", "Cruz Bosh", new Date('1980-08-03'), "Female")
    ];
    this.nextId = 8;
    this.dataSource.data = this.workersList;
    this.dataSource.paginator = this.paginator;      
    this.dataSource.paginator._changePageSize(10)            
    this.dataSource.sort = this.sort;
    this.dataSource.sort.sort(<MatSortable>{id: 'firstName', start: 'asc'})
  }

  ngOnDestroy(){}

  getGenders(){
    return ['Male', 'Female'];
  }

  get formAddUpdate(){return this.addUpdateWorkerFrm}

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getWorkersList(){
    return this.workersList == null ? [] : this.workersList;
  }

  onSelectRow(model: Worker){
    this.workerSelected = model;
  }

  onOpenNewWorker(){
    this.workerSelected = new Worker();
    this.addUpdateWorkerFrm.reset();
    this.action = "New";
  }

  onOpenUpdateWorker(worker: Worker){
    this.workerSelected = worker;
    this.action = "Update";
    this.addUpdateWorkerFrm.patchValue({
      firstName: worker.firstName,
      lastName: worker.lastName,
      birthday: worker.birthday,
      gender: worker.gender
    })
    
  }

  rowSelected(model: Worker){
    return {'background-color': (this.workerSelected != null && this.workerSelected.workerId == model.workerId) ? '#48abf7' : 'white', 
            'color': (this.workerSelected != null && this.workerSelected.workerId == model.workerId) ? 'white' : '#424242',
            'font-weight': (this.workerSelected != null && this.workerSelected.workerId == model.workerId) ? 'bold' : 'normal'
    }
  }

  confirmDeleteUser(){
    this.sweetAlert.confirm(()=>this.onDelete(), 'Are you sure you want to delete this worker?');
  }

  onDelete(){
    let pos = this.workersList.findIndex(x=>x.workerId == this.workerSelected.workerId);
    this.workersList.splice(pos, 1);
    this.dataSource.data = this.workersList;
    this.notifyService.success('Worker deleted satisfactory');
  }

  onSaveData(){
    if(this.action == 'New'){
      this.workersList.push(new Worker(this.nextId, this.addUpdateWorkerFrm.get('firstName').value, this.addUpdateWorkerFrm.get('lastName').value, new Date(this.addUpdateWorkerFrm.get('birthday').value), this.addUpdateWorkerFrm.get('gender').value));
      this.dataSource.data = this.workersList;
      this.nextId++;
      this.notifyService.success('Worker added satisfactory');
    }
    else{
      this.workerSelected.firstName = this.addUpdateWorkerFrm.get('firstName').value;
      this.workerSelected.lastName = this.addUpdateWorkerFrm.get('lastName').value;
      this.workerSelected.birthday = this.addUpdateWorkerFrm.get('birthday').value;
      this.workerSelected.gender = this.addUpdateWorkerFrm.get('gender').value;
      let pos = this.workersList.findIndex(x=>x.workerId == this.workerSelected.workerId);
      this.workersList[pos] = this.workerSelected;
      this.dataSource.data = this.workersList;
      this.workerSelected = null;
      this.notifyService.success('Worker updated satisfactory');
    }

    
  }

}
