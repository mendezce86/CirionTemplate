import { NgModule } from '@angular/core';
import { WorkerComponent } from './worker/worker.component';
import { SharedModule } from '../shared/modules/shared.module';
import { routingCatalog } from './catalog.routing';



@NgModule({
  declarations: [WorkerComponent],
  imports: [
    routingCatalog,
    SharedModule
  ]
})
export class CatalogModule { }
