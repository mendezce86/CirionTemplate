export class Worker{
    workerId: number;
    firstName: string;
    lastName: string;
    birthday: Date;
    gender: string; 
    

    constructor(workerId: number = 0, firstname: string = "", lastname: string = "", birthday: Date = null, gender: string = "") {
        this.workerId = workerId;
        this.firstName = firstname;
        this.lastName = lastname;
        this.birthday = birthday;
        this.gender = gender;
    }
}