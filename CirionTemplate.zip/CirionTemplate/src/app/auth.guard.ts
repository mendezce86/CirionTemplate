// auth.guard.ts
import { Injectable } from '@angular/core';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserService } from './shared/services/user.service';
import { MenuService } from './shared/services/menu.service';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(private user: UserService, private router: Router, private serviceMenu: MenuService) {}

  canActivate() { 
    if(!this.user.isLoggedIn())
    {
       this.router.navigate(['/login']);
       return false;
    }    
    return true;
  }
  
  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
    if(!this.user.isLoggedIn())
    {
       this.router.navigate(['/login']);
       return false;
    }
    else{
      this.serviceMenu.setHeaderMenu(state.url);
      return true;
    }
  }
}