export class Menu{
    menuId: number;
    tasmanAppId: number;
    name: string;
    description: string;
    parent: number;
    active: boolean;
    icon: string;
    url: string;
    isButton: boolean;
    leaf: boolean;
    expanded: boolean;
    children: Menu[]
    selected: boolean;
    buttonStyle: string;
    checked: boolean;

    /**
     *
     */
    constructor() {
        this.active = true;
        this.children = []
        
    }
}

export class NavigationModel{
    public id: number;
    public name: string;
    public icon: string;
    public children: NavigationModel[];
    public checked: boolean;
}