export interface IAppConfig{
    apiURI: string;
    logoExt: string;
    logoCompany: string;
    appName: string;
    menus: [];
}