export class FilterReport{
    fieldId1: number;
    fieldId2: number;
    fieldId3: number;
    fieldId4: number;
    fieldId5: number;
    aux1: string;
    dateFrom: Date;
    dateTo: Date;

    constructor(){
        this.aux1 = "";
    }
}