// include directives/components commonly used in features modules in this shared modules
// and import me into the feature module
// importing them individually results in: Type xxx is part of the declarations of 2 modules: ... Please consider moving to a higher module...
// https://github.com/angular/angular/issues/10646  

import { NgModule  }           from '@angular/core';
import { CommonModule }       from '@angular/common';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatCheckboxModule,
  MatSortModule,
  MatSelectModule,
  MatDatepickerModule
} from '@angular/material';
import { HeaderComponent } from '../header/header.component';

const modules = [
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatSortModule,
  MatTableModule,
  MatDatepickerModule,
  MatCheckboxModule,
  MatSelectModule,
  FormsModule,
  CommonModule,
  ReactiveFormsModule
];

@NgModule({
  imports:[...modules],
  declarations: [HeaderComponent],
  exports:      [HeaderComponent, NgxPermissionsModule, ...modules],
  providers:    []
})
export class SharedModule { }