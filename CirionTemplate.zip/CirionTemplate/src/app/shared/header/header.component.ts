import { Component, OnInit } from '@angular/core';
import { MenuService } from '../services/menu.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  constructor(private service: MenuService) {}

  ngOnInit() {    
  }

  isPageActive(pos: number){    
    return this.getHeaderMenu().length == (pos + 1);
  }

  getHeaderMenu(){
    debugger
    return this.service.getHeaderAccess();
  }

  showHeaderMenu(){
    return this.getHeaderMenu().length > 0;
  }

  gotoUrl(url){
    this.service.gotoUrl(url);
  }

}
