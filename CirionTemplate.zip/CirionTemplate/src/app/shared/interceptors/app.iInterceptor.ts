import { Injectable } from "@angular/core";
import {
    HttpInterceptor,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HTTP_INTERCEPTORS,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';

// import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { NotificationService } from "../services/notification.service";
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from "rxjs/operators";
import { NgxSpinnerService } from 'ngx-spinner';
import { Constants } from '../utils/constant.class';

  
@Injectable()
export class AppInterceptor implements HttpInterceptor {      
    constructor(private spinner: NgxSpinnerService, private notificationService: NotificationService) { 
    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.spinner.show();  
    const request = req.clone({  
                setHeaders: {  
                    'Authorization': `Bearer ${localStorage.getItem(Constants.lsAuth_token)}`,
                    'content-type': 'application/json'  
                }  
    }) 
    return next.handle(request).pipe(
        tap(evt => {
            if (evt instanceof HttpResponse) {
                this.spinner.hide();
            }
        }),
        catchError((ex: HttpErrorResponse) => {
             this.spinner.hide();  
            if ((ex.status === 401 || ex.status === 403) && (window.location.href.match(/\?/g) || []).length < 2) {
                
                /* Great solution for bundling with Auth Guard! 
                1. Auth Guard checks authorized user (e.g. by looking into LocalStorage). 
                2. On 401/403 response you clean authorized user for the Guard (e.g. by removing coresponding parameters in LocalStorage). 
                3. As at this early stage you can't access the Router for forwarding to the login page,
                4. refreshing the same page will trigger the Guard checks, which will forward you to the login screen */                
                localStorage.removeItem(Constants.lsAuth_token);       
                localStorage.removeItem(Constants.lsHomeDetails);
                window.location.href = window.location.href + '?' + new Date().getMilliseconds();             
            }
            else if(!ex.url.includes('login')){
                this.notificationService.error(ex.status == 0 ? 'An error has ocurred, please contact the administrator and try later.': ex.error);
                // this.toaster.error(ex.error, "Error");
            }
            else {                                
                return (ex.error['login_failure'] == null) ? throwError('An error has ocurred, please contact the administrator and try later.') : throwError(ex.error['login_failure'])
            }
            return throwError(ex);// Observable.throw(ex);
        }));
    }
} 

/**
 * Provider POJO for the interceptor
 */
export const AppInterceptorProvider = {    
    provide: HTTP_INTERCEPTORS,
    useClass: AppInterceptor,
    multi: true,
};