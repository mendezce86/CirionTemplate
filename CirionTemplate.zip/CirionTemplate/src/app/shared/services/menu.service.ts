import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Constants } from '../utils/constant.class';
import { Menu, NavigationModel } from '../models/menu.class';
import { HomeDetails } from 'src/app/dashboard/models/homedetails.class';


@Injectable()
export class MenuService{
    private homeDetails: HomeDetails;    
    private subMenuList: Array<Menu>;    
    private headerAccessMenu: Array<Menu>;   
    public listMenuTree: NavigationModel[] = []; 
    private currentPageTitle: string;
    /**
     *
     */
    constructor(private router: Router) {        
    }

    // initializeSubMenu(parentId: number = -1){     
    //     if(parentId == -1){
    //         const menu = this.checkAccess();
    //         this.subMenuList =  this.homeDetails.menus.filter(x=>x.parent == menu.menuId).sort((a, b)=> a.name.localeCompare(b.name));
    //     }
    //     else
    //     {
    //         this.homeDetails = JSON.parse(localStorage.getItem(Constants.lsHomeDetails)); 
    //         if(this.homeDetails != null)
    //             this.subMenuList = this.homeDetails.menus.filter(x=>x.parent == parentId).sort((a, b)=> a.menuId > b.menuId ? 1 : -1);
    //     }        
    // }

    onLoadMenu(){   
        this.homeDetails = JSON.parse(localStorage.getItem(Constants.lsHomeDetails));  
        this.listMenuTree = null;           
        const nest = (items, id = 0, link = 'parent') => items.filter(item => item[link] === id)
        .map(item => ({ ...item, expanded: item.expanded, children: nest(items, item.menuId) }));
          this.listMenuTree = nest(this.homeDetails.menus.filter(x=>x.isButton == false).sort((a,b)=> a.menuId > b.menuId ? 1 : -1 ));
          return this.listMenuTree;
    }

    getMenuList(){
        return this.listMenuTree == null ? [] : this.listMenuTree;
    }

    getButtons(){
        const menu = this.checkAccess();
        return this.homeDetails.menus.filter(x=>x.parent == menu.menuId && x.isButton).sort((a, b)=> a.menuId > b.menuId ? 1 : -1);
    }
    
    getSubMenu(){
        return this.subMenuList == null ? [] : this.subMenuList;
    }
    
    checkAccess(url: string = this.router.url){    
        this.homeDetails = JSON.parse(localStorage.getItem(Constants.lsHomeDetails));         
        if(this.homeDetails.menus.findIndex(x=>x.url == url) == -1)
            this.router.navigateByUrl('/sessionexpired');
        else return this.homeDetails.menus.find(x=>x.url == url);
    }

    getHeaderAccess(){        
        return this.headerAccessMenu == null ? [] : this.headerAccessMenu;
    }

    getRole(){
        return this.homeDetails == null ? '' : this.homeDetails.role;
    }

    isExternalPlant(){
        return this.homeDetails != null &&  this.homeDetails.role == 'ExternalPlant';
    }

    recursiveMenu(menudId: number, value: Menu[]){
        if(this.homeDetails.menus.findIndex(x=>x.menuId == menudId) == -1)
            return;
        else{
            let menu = this.homeDetails.menus.find(x=>x.menuId == menudId);
            value.push(menu);
            this.recursiveMenu(menu.parent, value)
        }
    }

    gotoUrl(url){
         this.router.navigateByUrl(url);        
    }

    setHeaderMenu(url: string){
        if(this.homeDetails == null || url == "/dashboard/home" || url == '/')
            this.headerAccessMenu = [];
        else{
            const menu = this.checkAccess(url);
            let auxAccess = [];
            this.recursiveMenu(menu.menuId, auxAccess);            
            this.headerAccessMenu = auxAccess.slice().reverse();      
            this.currentPageTitle = menu.name;
        }
    }

    getCurrentPageTitle(){
        return this.currentPageTitle == null ? 'Dashboard' : this.currentPageTitle;
    }

}