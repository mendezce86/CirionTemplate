import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { IAppConfig } from '../models/appconfig.interface';

export function configProvider(cs: ConfigService) {
    return () => cs.loadConfig();
}

@Injectable({
    providedIn: 'root'
})

export class ConfigService {
    
   private appConfig: IAppConfig;
   constructor(private http: HttpClient) {}

   loadConfig() {  
             
        const jsonFile = `assets/config/config.${environment.name}.json`;
        return new Promise<void>((resolve, reject) => {
            this.http.get(jsonFile).toPromise().then((response: any) => { 
            this.appConfig = response;
            resolve();
            }).catch((response: any) => {  
                reject(`Could not load file '${jsonFile}': ${JSON.stringify(response)}`);
            });
        });
        this.loadMenus();
    }

    loadMenus(){
        const jsonFile = `assets/config/menu.json`;
        return new Promise<void>((resolve, reject) => {
            this.http.get(jsonFile).toPromise().then((response: any) => { 
            this.appConfig.menus = response;
            resolve();
            }).catch((response: any) => {  
                reject(`Could not load file '${jsonFile}': ${JSON.stringify(response)}`);
            });
        });
    }

    getApiURI() {
        return this.appConfig.apiURI;
    }  
    
    getAppName() {
        return this.appConfig.appName;
    } 

    getAppMenus(){
        return this.appConfig.menus;
    }
}
