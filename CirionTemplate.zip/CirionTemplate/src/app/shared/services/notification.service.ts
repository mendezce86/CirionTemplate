import { Injectable } from "@angular/core";

declare const $: any;

@Injectable({
    providedIn: 'root'
})

export class NotificationService{

    private placementFrom: string = 'top';
    private placementAlign: string = 'right';
    private content: any = {};
    
    success(text, placementFrom?, placementAlign?){
        this.content.message = text,
        this.content.title = 'Success',
        this.content.icon = 'fa fa-bell'
        $.notify(this.content,{
            type: 'success',
            allow_dismiss: true,
            newest_on_top: true,
            timer: 1000,
            placement: {
                from: placementFrom == null ? this.placementFrom : placementFrom,
                align: placementAlign == null ? this.placementAlign : placementAlign
            },
            animate: {
                enter: 'animated flipInY',
                exit: 'animated flipOutY'
            }
        });
    }

    error(text, placementFrom?, placementAlign?){
        this.content.message = text,
        this.content.title = 'Error',
        this.content.icon = 'fa fa-bell'
        $.notify(this.content,{
            type: 'danger',
            allow_dismiss: true,
            newest_on_top: true,
            timer: 1000,
            placement: {
                from: placementFrom == null ? this.placementFrom : placementFrom,
                align: placementAlign == null ? this.placementAlign : placementAlign
            },
            animate: {
                enter: 'animated flipInY',
                exit: 'animated flipOutY'
            }
        });
    }



}