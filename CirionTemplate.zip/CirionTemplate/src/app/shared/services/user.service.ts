import { Injectable } from '@angular/core';
import { ConfigService } from './config.service';

import {BaseService} from "./base.service";

// Add the RxJS Observable operators we need in this app.
import { Credentials } from "../models/credentials.interface";
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Constants } from '../utils/constant.class';

@Injectable()

export class UserService extends BaseService {

  baseUrl: string = '';

  // Observable navItem source
  private _authNavStatusSource = new BehaviorSubject<boolean>(false);
  // Observable navItem stream
  authNavStatus$ = this._authNavStatusSource.asObservable();

  private loggedIn = false;

  constructor(private http: HttpClient, private configService: ConfigService) {
    super();
    this.loggedIn = !!localStorage.getItem(Constants.lsAuth_token);
    // ?? not sure if this the best way to broadcast the status but seems to resolve issue on page refresh where auth status is lost in
    // header component resulting in authed user nav links disappearing despite the fact user is still logged in
    this._authNavStatusSource.next(this.loggedIn);
    this.baseUrl = this.configService.getApiURI();    
  }

   login(credentials: Credentials) {    
    return this.http
      .post(this.baseUrl + '/auth/login', credentials)
      .pipe(map((res: any) => {
        let data = JSON.parse(res);
        localStorage.setItem(Constants.lsAuth_token, data.auth_token);                
        this.loggedIn = true;
        this._authNavStatusSource.next(true);
        return this.loggedIn;
    }));    
  }

  logout() {
    localStorage.removeItem(Constants.lsHomeDetails);
    localStorage.removeItem(Constants.lsUserId);
    localStorage.removeItem(Constants.lsAuth_token);   
    this.loggedIn = false;
    this._authNavStatusSource.next(false);
    window.location.href = '';
  }

  isLoggedIn() {
    return this.loggedIn;
  }  
}

