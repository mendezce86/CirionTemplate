import { Injectable } from "@angular/core";
declare var swal: any;

export enum TypeAlert{
  success = 'success',
  error = 'error',
  warning = 'warning',
  info = 'info'
}

@Injectable({
    providedIn: 'root'
})

export class SweetAlert {

  alert(type: TypeAlert, tittle = "", text = "", callback: () => void = null){
    swal({
        title: tittle,
        text: text,
        closeOnClickOutside: false,
        closeOnEsc: true,
        icon: type.toString(),
        buttons: {
          confirm: {
            text: "Ok",
            value: true,
            visible: true,
            className: "btn btn-success",
            closeModal: true
          }
        }
      }).then(() => {
        if (callback != null) {
          callback();
        } 
      });
    }
    
    confirm(callback: () => void, text: string, production: boolean = false, title: string = ''){
      swal({
        title: title == '' ? 'Confirmation' : title,
        text:  text ,
        icon: 'warning',
        type: 'warning',
        customClass: {
          title: production ? 'swal-title-prod' : 'swal-title',
          content: production ? 'swal-text-prod' : 'swal-text'
        },
        closeOnClickOutside: false,
        closeOnEsc: true,
        buttons:{          
          cancel: {
            visible: true,
            className: 'btn btn-default'
          },
          confirm: {
            text : '      Yes      ',
            className : 'btn btn-success',
            width: '180%'
          }
        }
      }).then((Delete) => {
        if (Delete) {
          callback();
        } else {
          swal.close();
        }
      });
    }
}