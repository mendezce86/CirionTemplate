export class Constants {    
    public static get lsAuth_token(): string { return 'auth_tokenAdmin'; };
    public static get lsHomeDetails(): string { return 'homeDetailsAdmin'; };
    public static get lsUserId(): string { return 'userIdAdmin'; };

  }