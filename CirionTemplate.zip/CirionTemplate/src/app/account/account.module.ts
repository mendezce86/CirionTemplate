import { NgModule } from '@angular/core';
import { LoginFormComponent } from './login-form/login-form.component';
import { routingAccount } from './account.routing';
import { SharedModule } from '../shared/modules/shared.module';
import { UserService } from '../shared/services/user.service';



@NgModule({
  declarations: [LoginFormComponent],
  imports: [    
    routingAccount,
    SharedModule    
  ] ,  
  providers:    [ UserService ]
})
export class AccountModule { }
