import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Credentials } from '../../shared/models/credentials.interface';
import { UserService } from '../../shared/services/user.service';
import { ConfigService } from '../../shared/services/config.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Constants } from 'src/app/shared/utils/constant.class';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class LoginFormComponent implements OnInit, OnDestroy {

  
  private subscription: Subscription;

  brandNew: boolean;
  errors: string;
  isRequesting: boolean;
  submitted: boolean = false;
  credentials: Credentials = { username: '', password: '', app: '' };

  constructor(private userService: UserService, private router: Router,private activatedRoute: ActivatedRoute) { }

    ngOnInit() {
    localStorage.removeItem(Constants.lsAuth_token);
    localStorage.removeItem(Constants.lsHomeDetails);
    // subscribe to router event
        
  }

   ngOnDestroy() {
    // prevent memory leak by unsubscribing
  }

  login() {    
    this.router.navigateByUrl('/dashboard/home');
  }
}
