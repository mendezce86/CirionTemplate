import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BaseService } from '../shared/services/base.service';
import { ConfigService } from '../shared/services/config.service';
import { HomeDetails } from "./models/homedetails.class";

@Injectable()
export class DashboardService extends BaseService {

  baseUrl: string = ''; 

  constructor(private http: HttpClient, private configService: ConfigService) {
     super();
     this.baseUrl = this.configService.getApiURI();
  }

  getHomeDetails(): Observable<HomeDetails> {
    return this.http.get<HomeDetails>(this.baseUrl + "/dashboard");
  }

     
}
