import { Menu } from 'src/app/shared/models/menu.class';

export class HomeDetails{
    fullName: string;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
    menus: Array<Menu>;
}