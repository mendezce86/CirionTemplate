import { ModuleWithProviders } from '@angular/core';
import { RouterModule }        from '@angular/router';
import { RootComponent }    from './root/root.component';
import { HomeComponent }    from './home/home.component'; 
import { AuthGuard } from '../auth.guard';

export const routingDashboard: ModuleWithProviders = RouterModule.forChild([
  {
      path: 'dashboard', component: RootComponent,
      children: [      
       { path: '', component: HomeComponent, data: { title: 'Home'} },
       { path: 'home',  component: HomeComponent, data: { title: 'Home'} },
      ]       
    }  
]);

