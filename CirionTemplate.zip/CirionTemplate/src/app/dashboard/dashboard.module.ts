import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { HomeComponent } from './home/home.component';
import { routingDashboard } from './dashboard.routing';
import { SharedModule } from '../shared/modules/shared.module';
import { AuthGuard } from '../auth.guard';
import { DashboardService } from './dashboard.service';

@NgModule({
  declarations: [RootComponent, HomeComponent],
  imports: [
    routingDashboard,
    SharedModule
  ],
  providers:[DashboardService]
})
export class DashboardModule { }
