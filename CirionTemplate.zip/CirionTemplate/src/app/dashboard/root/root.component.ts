import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxPermissionsService } from 'ngx-permissions';
import { UserService } from '../../shared/services/user.service';
import { Subscription } from 'rxjs';
import { Constants } from 'src/app/shared/utils/constant.class';
import { MenuService } from 'src/app/shared/services/menu.service';
import { Menu, NavigationModel } from 'src/app/shared/models/menu.class';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/shared/services/config.service';
import { HomeDetails } from '../models/homedetails.class';
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.scss']
})
export class RootComponent implements OnInit, OnDestroy {

  private subscription: Subscription;
  homeDetails: HomeDetails;
  public listMenuTree: NavigationModel[];

  constructor(private router: Router, private menuService: MenuService, private permissionsService: NgxPermissionsService, private userService: UserService, private configService:  ConfigService) { }
    
  ngOnInit() {
    $(document).ready(function() {"use strict";
    $('.menu > ul > li:has( > ul)').addClass('menu-dropdown-icon');
    //Checks if li has sub (ul) and adds class for toggle icon - just an UI
  
    $('.menu > ul > li > ul:not(:has(ul))').addClass('normal-sub');
    $(".menu > ul > li").hover(function(e) {
      if ($(window).width() > 943) {
      $(this).children("ul").stop(true, false).fadeToggle(150);
      e.preventDefault();
      }
    });
    //If width is more than 943px dropdowns are displayed on hover    

    $(".menu > ul > li").click(function() {
      if ($(window).width() <= 943) {
      $(this).children("ul").fadeToggle(150);
      }
    });
    //If width is less or equal to 943px dropdowns are displayed on click (thanks Aman Jain from stackoverflow)
  
    $(".h-bars").click(function(e) {
      $(".menu > ul").toggleClass('show-on-mobile');
      e.preventDefault();
    });
    //when clicked on mobile-menu, normal menu is shown as a list, classic rwd menu story (thanks mwl from stackoverflow)
  
  });   
  
  this.homeDetails = JSON.parse(localStorage.getItem(Constants.lsHomeDetails));
  if(this.homeDetails == null)
  {
    this.homeDetails = new HomeDetails();
    this.homeDetails.email = "template@gmail.com";
    this.homeDetails.fullName =  'Template';
    this.homeDetails.firstName =  'Test';
    this.homeDetails.lastName =  'Template Test';
    this.homeDetails.role = "Admin";
    this.homeDetails.menus = this.configService.getAppMenus();
    this.permissionsService.addPermission(this.homeDetails.role);
    localStorage.setItem(Constants.lsHomeDetails, JSON.stringify(this.homeDetails));       
    this.listMenuTree = this.menuService.onLoadMenu();                      
    
  }
  else{  
      this.permissionsService.addPermission(this.homeDetails.role);
      this.listMenuTree = this.menuService.onLoadMenu();
    }
}

  ngOnDestroy(){
    if(this.subscription != null)
      this.subscription.unsubscribe();
  }

  getUserName(){
    return (this.homeDetails == null) ? '' : this.homeDetails.fullName;
  }
  
  getEMail(){
    return (this.homeDetails == null) ? '' : this.homeDetails.email;
  }

  getRole(){
    return (this.homeDetails == null) ? '' : this.homeDetails.role;
  }

  logout(){    
    this.userService.logout();    
  } 
  
  onGoToUrl(menu){
    if(menu.children.length == 0)
    {
      this.router.navigateByUrl(menu.url);
    }
    
  }

  getIconMenu(menu: Menu){
    return menu.icon;
  }

  isLeaf(menu: Menu){    
    return menu.leaf || menu.isButton;
  }

  hasChildrens(menu: Menu){
    return menu.children.length > 0;
  }

  getPageName(){
    return this.menuService.getCurrentPageTitle();
  }
}
