import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { routingRoot } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/modules/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { NgxSpinnerModule } from "ngx-spinner";
import { ConfigService, configProvider } from './shared/services/config.service';
import { AppInterceptorProvider } from './shared/interceptors/app.iInterceptor';
import { AccountModule } from './account/account.module';
import { NotificationService } from './shared/services/notification.service';
import { DashboardModule } from './dashboard/dashboard.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { SweetAlert } from './shared/services/sweet.alert';
import { MenuService } from './shared/services/menu.service';
import { CatalogModule } from './catalog/catalog.module';

@NgModule({
  declarations: [
    AppComponent    
  ],
  imports: [
    routingRoot,
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpClientModule,
    AccountModule,
    DashboardModule,
    CatalogModule,
    NgxSpinnerModule,
    NgxPermissionsModule.forRoot()
  ],
  providers: [ ConfigService, AppInterceptorProvider, NotificationService, SweetAlert, MenuService,
    {
      deps: [ConfigService],
      multi: true,
      provide: APP_INITIALIZER,
      useFactory: configProvider,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
